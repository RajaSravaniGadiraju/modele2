package com.cg.SessionScheduleManagement.service;

import java.util.List;

import com.cg.SessionScheduleManagement.beans.ScheduledSessions;

public interface ITrainingService {
	
	public List<ScheduledSessions> getAllSession();

}

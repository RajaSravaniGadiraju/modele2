package com.cg.SessionScheduleManagement.beans;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ScheduledSessions {
	@Id
	private int id;
	private String name;
	private int duration;
	private String faculty;
	private String model;
	
	
	public ScheduledSessions() {
		super();
	}
	
	public ScheduledSessions(int id, String name, int duration, String faculty, String model) {
		super();
		this.id = id;
		this.name = name;
		this.duration = duration;
		this.faculty = faculty;
		this.model = model;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public String getFaculty() {
		return faculty;
	}
	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}




}

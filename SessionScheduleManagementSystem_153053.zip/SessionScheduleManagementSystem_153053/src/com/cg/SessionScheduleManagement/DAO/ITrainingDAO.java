package com.cg.SessionScheduleManagement.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.SessionScheduleManagement.beans.ScheduledSessions;

public interface ITrainingDAO extends JpaRepository<ScheduledSessions, Integer>{

}
